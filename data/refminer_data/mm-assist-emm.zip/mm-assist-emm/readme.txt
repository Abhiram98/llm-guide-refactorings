setup: context limit of 128k tokens
model: gpt-4o
temp: 0.0
approach: Use tf-idf to compute method compatibility
filter out methods which have no "envy"